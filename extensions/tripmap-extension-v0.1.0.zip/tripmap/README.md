# TripMap Chrome 擴充套件 v0.1

第一版只顯示入口，不登入、不呼叫新增 API、不儲存地點、不套用標籤。
只依「名稱＋地點座標」判斷，不需要 Place ID；不限制沖繩範圍。

## 安裝

1. 電腦 Chrome 開啟 `chrome://extensions`。
2. 開啟右上角「開發人員模式」。
3. 點「載入未封裝項目」，選取此資料夾：
   `/home/ubuntu/workspace/Travel/extensions/tripmap`。
   若瀏覽器在另一台電腦，先複製此資料夾或解壓縮 tripmap-extension-v0.1.0.zip 到該電腦。
4. 開啟／重新整理 Google Maps 分頁。更新擴充套件後，也要重新整理已開啟的 Maps 分頁。

## 使用與判斷

- 支援 `google.com`、`google.com.tw`、`google.co.jp`、`google.co.uk` 的 Google Maps。
- 在 Google Maps 搜尋並選取**單一地點**；最終網址需有 `/maps/place/名稱/`，以及 `!3d緯度!4d經度` 地點座標。
- 符合條件時，右上方顯示 TripMap 按鈕，滑鼠移上可看到地點名稱。
- 使用瀏覽器原生右鍵選單時顯示「加入 TripMap 地點」。若地圖區域攔截右鍵，可在詳細資料面板的非連結空白處按右鍵。
- 切換地點、上一頁／下一頁與分頁切換時會重新判斷。
- 只有 `@緯度,經度` 的地圖中心、搜尋列表、尚未展開的短網址、資料不全或多組不同地點座標，皆不顯示入口。
- 短網址經 Google 自動導向成符合條件的詳細網址後即可顯示；本版不另外解析短網址。
- 這是保守辨識的第一版：不支援的網址格式會隱藏入口，不以地圖中心代替地點位置。

按鈕與右鍵選單目前只在 Console 記錄解析結果，不會顯示「新增成功」或寫入資料。
右鍵選單 log 可至 `chrome://extensions` 點此擴充套件的 Service worker「檢查」查看。

## 驗證

```bash
node --test extensions/tripmap/place-url.check.mjs
```
